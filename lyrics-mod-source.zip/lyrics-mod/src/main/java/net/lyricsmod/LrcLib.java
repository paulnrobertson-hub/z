package net.lyricsmod;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;

/** Looks up time-synced lyrics from LRCLIB (free, no account needed). */
final class LrcLib {
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();

    static List<Lrc.Line> fetch(String artist, String track, long durationMs) throws Exception {
        String lrc = null;

        String url = "https://lrclib.net/api/get?artist_name=" + enc(artist) + "&track_name=" + enc(track)
                + (durationMs > 0 ? "&duration=" + (durationMs / 1000) : "");
        JsonElement e = get(url);
        if (e != null && e.isJsonObject()) lrc = synced(e.getAsJsonObject());

        if (lrc == null) {
            JsonElement s = get("https://lrclib.net/api/search?q=" + enc((artist + " " + track).trim()));
            if (s != null && s.isJsonArray()) {
                JsonArray arr = s.getAsJsonArray();
                for (JsonElement item : arr) {
                    String found = synced(item.getAsJsonObject());
                    if (found != null) { lrc = found; break; }
                }
            }
        }
        return lrc == null ? List.of() : Lrc.parse(lrc);
    }

    private static String synced(JsonObject o) {
        if (!o.has("syncedLyrics") || o.get("syncedLyrics").isJsonNull()) return null;
        String s = o.get("syncedLyrics").getAsString();
        return s.isBlank() ? null : s;
    }

    private static JsonElement get(String url) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .header("User-Agent", "LyricsMod/1.0 (Minecraft Fabric mod)")
                .timeout(Duration.ofSeconds(10)).GET().build();
        HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        return res.statusCode() == 200 ? JsonParser.parseString(res.body()) : null;
    }

    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
}
