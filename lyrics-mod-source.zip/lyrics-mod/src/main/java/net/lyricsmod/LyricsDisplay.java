package net.lyricsmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.DisplayEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

/**
 * Shows lyrics as a client-side-only vanilla text_display entity (billboarded, so it
 * always faces you) floating in front of the camera. Nothing is sent to the server.
 */
final class LyricsDisplay {
    private static final int ENTITY_ID = -736251;

    double distance = 3.5;
    double height = 0.4;

    private DisplayEntity.TextDisplayEntity entity;
    private ClientWorld world;
    private String lastKey = "";

    void show(MinecraftClient mc, Text text, String key) {
        ClientWorld w = mc.world;
        if (w == null) { reset(); return; }
        if (entity == null || world != w || entity.isRemoved()) {
            entity = new DisplayEntity.TextDisplayEntity(EntityType.TEXT_DISPLAY, w);
            entity.setId(ENTITY_ID);
            entity.setBillboardMode(DisplayEntity.BillboardMode.CENTER);
            entity.setLineWidth(600);
            w.addEntity(entity);
            world = w;
            lastKey = "";
        }
        if (!key.equals(lastKey)) {
            entity.setText(text);
            lastKey = key;
        }
        if (mc.player != null) {
            Vec3d eye = mc.player.getEyePos();
            Vec3d p = eye.add(mc.player.getRotationVec(1.0f).multiply(distance));
            entity.refreshPositionAndAngles(p.x, p.y + height, p.z, 0f, 0f);
        }
    }

    void hide() {
        if (entity != null) { entity.discard(); entity = null; }
        lastKey = "";
    }

    void reset() { hide(); world = null; }
}
