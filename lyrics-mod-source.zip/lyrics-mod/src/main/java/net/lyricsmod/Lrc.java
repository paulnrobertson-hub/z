package net.lyricsmod;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parses LRC (time-synced) lyrics. */
final class Lrc {
    record Line(long timeMs, String text) {}

    private static final Pattern TS = Pattern.compile("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]");

    static List<Line> parse(String lrc) {
        List<Line> out = new ArrayList<>();
        for (String raw : lrc.split("\\R")) {
            Matcher m = TS.matcher(raw);
            List<Long> times = new ArrayList<>();
            int idx = 0;
            while (m.find(idx) && m.start() == idx) {
                long min = Long.parseLong(m.group(1));
                long sec = Long.parseLong(m.group(2));
                String f = m.group(3);
                long ms = f == null ? 0 : Long.parseLong((f + "00").substring(0, 3));
                times.add(min * 60_000 + sec * 1000 + ms);
                idx = m.end();
            }
            if (times.isEmpty()) continue;
            String text = raw.substring(idx).trim();
            if (text.isEmpty()) text = "\u266A";
            for (long t : times) out.add(new Line(t, text));
        }
        out.sort(Comparator.comparingLong(Line::timeMs));
        return out;
    }

    /** Index of the last line whose time is <= pos, or -1 if before the first line. */
    static int indexAt(List<Line> lines, long pos) {
        int lo = 0, hi = lines.size() - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (lines.get(mid).timeMs() <= pos) { ans = mid; lo = mid + 1; } else hi = mid - 1;
        }
        return ans;
    }
}
