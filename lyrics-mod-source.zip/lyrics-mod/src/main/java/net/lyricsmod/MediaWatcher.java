package net.lyricsmod;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Reads "now playing" from Windows' media controls (the same info your keyboard
 * play/pause key uses) via a small PowerShell script. Works for Spotify, and for
 * YouTube / SoundCloud playing in Chrome, Edge, etc.
 */
final class MediaWatcher {
    record Snap(String app, String title, String artist, boolean playing,
                long positionMs, long durationMs, long receivedAt) {}

    private static final String SCRIPT = """
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, $t) { $m = $asTask.MakeGenericMethod($t); $n = $m.Invoke($null, @($op)); $n.Wait(-1) | Out-Null; $n.Result }
[void][Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
[void][Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType = WindowsRuntime]
$mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
while ($true) {
  try {
    $s = $mgr.GetCurrentSession()
    if ($s) {
      $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
      $t = $s.GetTimelineProperties()
      $i = $s.GetPlaybackInfo()
      $o = [ordered]@{
        app = $s.SourceAppUserModelId; title = $p.Title; artist = $p.Artist
        status = [string]$i.PlaybackStatus
        pos = [math]::Round($t.Position.TotalMilliseconds)
        end = [math]::Round($t.EndTime.TotalMilliseconds)
        upd = $t.LastUpdatedTime.ToUnixTimeMilliseconds()
        now = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
      }
      [Console]::Out.WriteLine(($o | ConvertTo-Json -Compress))
    } else { [Console]::Out.WriteLine('{"status":"None"}') }
  } catch { [Console]::Out.WriteLine('{"status":"Error"}') }
  Start-Sleep -Milliseconds 400
}
""";

    private volatile Snap snap;
    private Process proc;

    void start() {
        if (!System.getProperty("os.name", "").toLowerCase().contains("win")) {
            LyricsMod.LOG.warn("Lyrics mod needs Windows to read what's playing; media reader not started.");
            return;
        }
        Thread t = new Thread(this::run, "lyricsmod-media");
        t.setDaemon(true);
        t.start();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> { if (proc != null) proc.destroyForcibly(); }));
    }

    Snap snapshot() { return snap; }

    private void run() {
        while (true) {
            try {
                Path script = Files.createTempFile("lyricsmod", ".ps1");
                Files.writeString(script, SCRIPT, StandardCharsets.UTF_8);
                script.toFile().deleteOnExit();
                proc = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive",
                        "-ExecutionPolicy", "Bypass", "-File", script.toString())
                        .redirectError(ProcessBuilder.Redirect.DISCARD).start();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = r.readLine()) != null) parse(line);
                }
            } catch (Exception e) {
                LyricsMod.LOG.warn("Media reader error", e);
            }
            snap = null;
            try { Thread.sleep(5000); } catch (InterruptedException ignored) { return; }
        }
    }

    private void parse(String line) {
        try {
            JsonObject o = JsonParser.parseString(line).getAsJsonObject();
            String status = str(o, "status");
            if (status.equals("None") || status.equals("Error") || str(o, "title").isBlank()) { snap = null; return; }
            boolean playing = status.equals("Playing");
            long pos = lng(o, "pos"), end = lng(o, "end"), upd = lng(o, "upd"), now = lng(o, "now");
            long posNow = -1;
            if (end > 0) {
                posNow = playing ? pos + Math.max(0, now - upd) : pos;
                posNow = Math.min(posNow, end);
            }
            snap = new Snap(str(o, "app"), str(o, "title"), str(o, "artist"), playing, posNow, end, System.currentTimeMillis());
        } catch (Exception ignored) { /* partial line, skip */ }
    }

    private static String str(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
    }
    private static long lng(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsLong() : 0;
    }
}
