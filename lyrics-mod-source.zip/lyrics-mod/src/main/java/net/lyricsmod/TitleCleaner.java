package net.lyricsmod;

/** Turns messy player titles (esp. YouTube) into an {artist, track} guess. */
final class TitleCleaner {
    static String[] guess(String app, String title, String artist) {
        String t = title == null ? "" : title;
        String a = artist == null ? "" : artist;
        boolean spotify = app != null && app.toLowerCase().contains("spotify");

        a = a.replaceAll("(?i)\\s*-\\s*topic$", "").replaceAll("(?i)vevo$", "").trim();
        t = t.replaceAll("(?i)\\s*[\\(\\[][^\\)\\]]*(official|lyric|video|audio|visuali[sz]er|remaster|\\bhd\\b|\\bhq\\b|4k|explicit)[^\\)\\]]*[\\)\\]]", "");
        if (spotify) {
            t = t.replaceAll("(?i)\\s+-\\s+(\\d{4}\\s+)?(remaster(ed)?|live|mono|stereo|single version|radio edit).*$", "");
        } else {
            int d = t.indexOf(" - ");
            if (d > 0) { a = t.substring(0, d).trim(); t = t.substring(d + 3).trim(); }
        }
        t = t.replaceAll("(?i)\\s*[\\(\\[](feat|ft)\\.?[^\\)\\]]*[\\)\\]]", "").trim();
        return new String[] { a, t };
    }
}
