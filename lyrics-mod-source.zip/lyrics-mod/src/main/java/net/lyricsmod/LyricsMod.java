package net.lyricsmod;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.CompletableFuture;

public class LyricsMod implements ClientModInitializer {
    static final Logger LOG = LoggerFactory.getLogger("lyricsmod");

    private final MediaWatcher watcher = new MediaWatcher();
    private final LyricsDisplay display = new LyricsDisplay();

    private volatile List<Lrc.Line> lyrics = List.of();
    private volatile int loadState = 0; // 0 = searching, 1 = found, 2 = none found
    private volatile String loadedKey = "";
    private long fallbackPos = 0;
    private boolean enabled = true;
    private int offsetMs = 0;

    @Override
    public void onInitializeClient() {
        watcher.start();
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("lyrics")
                .executes(ctx -> {
                    enabled = !enabled;
                    ctx.getSource().sendFeedback(Text.literal("Lyrics " + (enabled ? "on" : "off")));
                    return 1;
                })
                .then(ClientCommandManager.literal("distance")
                    .then(ClientCommandManager.argument("blocks", DoubleArgumentType.doubleArg(1, 12))
                        .executes(ctx -> {
                            display.distance = DoubleArgumentType.getDouble(ctx, "blocks");
                            ctx.getSource().sendFeedback(Text.literal("Lyrics distance: " + display.distance));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("height")
                    .then(ClientCommandManager.argument("blocks", DoubleArgumentType.doubleArg(-3, 3))
                        .executes(ctx -> {
                            display.height = DoubleArgumentType.getDouble(ctx, "blocks");
                            ctx.getSource().sendFeedback(Text.literal("Lyrics height: " + display.height));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("offset")
                    .then(ClientCommandManager.argument("ms", IntegerArgumentType.integer(-10000, 10000))
                        .executes(ctx -> {
                            offsetMs = IntegerArgumentType.getInteger(ctx, "ms");
                            ctx.getSource().sendFeedback(Text.literal("Lyrics sync offset: " + offsetMs + " ms (positive = lyrics earlier)"));
                            return 1;
                        })))));
    }

    private void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) { display.reset(); return; }
        MediaWatcher.Snap s = watcher.snapshot();
        if (!enabled || s == null) { display.hide(); return; }

        String key = s.app() + "|" + s.title() + "|" + s.artist();
        if (!key.equals(loadedKey)) startLoad(s, key);

        long pos;
        if (s.positionMs() >= 0) {
            pos = s.positionMs() + (s.playing() ? System.currentTimeMillis() - s.receivedAt() : 0);
        } else {
            if (s.playing()) fallbackPos += 50; // player gives no timeline: count time ourselves
            pos = fallbackPos;
        }
        pos += offsetMs;

        List<Lrc.Line> l = lyrics;
        int state = loadState;
        if (state == 0) {
            display.show(mc, Text.literal("Searching lyrics...").formatted(Formatting.GRAY), "loading");
        } else if (state == 2 || l.isEmpty()) {
            display.show(mc, Text.literal("No synced lyrics found").formatted(Formatting.DARK_GRAY), "none");
        } else {
            int i = Lrc.indexAt(l, pos);
            String prev = i > 0 ? l.get(i - 1).text() : "";
            String cur = i >= 0 ? l.get(i).text() : "\u266A";
            String next = i + 1 < l.size() ? l.get(i + 1).text() : "";
            MutableText t = Text.empty();
            t.append(Text.literal(prev).formatted(Formatting.GRAY)).append(Text.literal("\n"));
            t.append(Text.literal(cur).setStyle(Style.EMPTY.withColor(0xD8B4FE).withBold(true))).append(Text.literal("\n"));
            t.append(Text.literal(next).formatted(Formatting.DARK_GRAY));
            display.show(mc, t, key + "#" + i);
        }
    }

    private void startLoad(MediaWatcher.Snap s, String key) {
        loadedKey = key;
        fallbackPos = 0;
        lyrics = List.of();
        loadState = 0;
        String[] ta = TitleCleaner.guess(s.app(), s.title(), s.artist());
        long dur = s.durationMs();
        LOG.info("Looking up lyrics for '{}' by '{}'", ta[1], ta[0]);
        CompletableFuture.runAsync(() -> {
            try {
                List<Lrc.Line> found = LrcLib.fetch(ta[0], ta[1], dur);
                if (key.equals(loadedKey)) { lyrics = found; loadState = found.isEmpty() ? 2 : 1; }
            } catch (Exception e) {
                LOG.warn("Lyrics lookup failed", e);
                if (key.equals(loadedKey)) loadState = 2;
            }
        });
    }
}
